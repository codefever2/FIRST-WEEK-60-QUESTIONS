import java.util.*;

class twentythree
  {
    public static void main(String[] args)
    {
      int x = 5;
      int y = (++x)-(x++)+(-x);
      System.out.println("output:"+y);
    }
  }
import java.util.*;

class twentyone
  {
    public static void main(String[] args)
    {
      int y = 10;
      int z = ((++y)*((y++)+5));
      System.out.println("output:"+z);
    }
  }
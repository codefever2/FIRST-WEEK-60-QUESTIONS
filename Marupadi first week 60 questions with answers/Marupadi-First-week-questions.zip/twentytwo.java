//false question same as qno:23
import java.util.*;

class twentytwo
  {
    public static void main(String[] args)
    {
      int x = 5;
      int y = (++x)-(x++)+(-x);
      System.out.println("output:"+y);
    }
  }
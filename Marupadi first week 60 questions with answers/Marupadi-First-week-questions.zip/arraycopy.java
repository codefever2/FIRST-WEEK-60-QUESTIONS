import java.util.*;
class arraycopy
  {
    public static void main(String[] args)
    {
      int[] array = new int[]{1,2,3,4,5,6,7,8,9,10};
      int[] numarray = new int[array.length];
      for(int i=0;i<array.length;i++)
        {
          numarray[i] = array[i];
          System.out.println("numarray["+i+"] = "+numarray[i]);
        }
    }
  }